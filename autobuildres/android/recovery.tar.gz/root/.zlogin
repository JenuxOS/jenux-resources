clear
if cat /proc/cmdline|grep -w nospeech;then
sleep .01
else
if [ -f /run/speech ];then
sleep .01
else
if [ -e /etc/asound.conf ];then
sleep .01
else
pick-a-card
fi
speechctl restart
touch /run//speech
fi
fi
androidrecovery
logout
