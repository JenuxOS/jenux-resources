if is-x-running||tty|grep -qw pts;then
sleep .01
else
fscrypt lock $HOME
fi
