source /etc/profile
source /etc/profile.d/*.sh
source ~/.txtfuncs
unset LS_COLORS
alias ls="ls -A1 --sort=version"
