(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(dtk-capitalize t)
 '(dtk-speech-rate 300)
 '(dtk-split-caps nil)
 '(emacspeak-audio-indentation t)
 '(emacspeak-audio-indentation-method (quote tone))
 '(emacspeak-auditory-icons t)
 '(emacspeak-character-echo nil)
 '(emacspeak-line-echo nil)
 '(emacspeak-punctuation-mode (quote none))
 '(emacspeak-word-echo nil))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 )

