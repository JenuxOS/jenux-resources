cd
if [ -f jenux.defaults ];then
echo setting up desktop for first use, please wait
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
cat orca.defaults|dconf load /org/gnome/orca/
for f in ".zlogin" ".profile" ".bash_profile";do
sed -i "/.\/applydef.sh/d" $f
done
rm jenux.defaults orca.defaults applydef.sh
else
sleep .01
fi
